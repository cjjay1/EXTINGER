import customtkinter as ctk
from tkinter import *
from PIL import Image
from tkinter import messagebox

janela = ctk.CTk()

class Application():
    def __init__(self):
        self.janela=janela
        self.tema()
        self.tela()
        self.tela_login()
        janela.mainloop()
        
        pass

    def tema(self):
        ctk.set_appearance_mode("dark")
    
    def tela(self):
        janela.geometry("600x480")
        janela.resizable(False,False)
        janela.title("EXTINAGER")
        janela.iconbitmap("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Login/extintor.ico")


    def tela_login(self):
    #Imagens
        side_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Login/side-img.png")
        user_icon_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Login/user-icon.png")
        password_icon_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Login/password-icon.png")
        email_icon_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Login/email-icon.png")
                
        #Alinhamento das imagens
        side_img = ctk.CTkImage(dark_image=side_img_data, light_image=side_img_data, size=(300, 480))
        user_icon = ctk.CTkImage(dark_image=user_icon_data, light_image=user_icon_data, size=(20,20))
        password_icon = ctk.CTkImage(dark_image=password_icon_data, light_image=password_icon_data, size=(17,17))
        email_icon = ctk.CTkImage(dark_image=email_icon_data, light_image=email_icon_data, size=(17,17))

        ctk.CTkLabel(master=janela, text="", image=side_img).pack(expand=True, side="left")

        #FRAME LOGIN
        login_frame = ctk.CTkFrame(master=janela, width=300, height=480, fg_color="#ffffff")
        login_frame.pack_propagate(0)
        login_frame.pack(expand=True, side="right")

        #TITULO,sub
        titulo = ctk.CTkLabel(master=login_frame, text="EXTINAGER", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 30)).pack(anchor="w", pady=(50, 5), padx=(25, 0))
        sub_tt = ctk.CTkLabel(master=login_frame, text="Sistema de gerenciamento de extintores.", text_color="#7E7E7E", anchor="w", justify="left", font=("Arial Bold", 12)).pack(anchor="w", padx=(25, 0))

        #Usuario e senha
        usuario_entry = ctk.CTkLabel(master=login_frame, text="  Usuário", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=user_icon, compound="left").pack(anchor="w", pady=(20, 0), padx=(25, 0))
        ctk.CTkEntry(master=login_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000").pack(anchor="w", padx=(25, 0))

        senha_entry = ctk.CTkLabel(master=login_frame, text="   Senha", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=password_icon, compound="left").pack(anchor="w", pady=(21, 0), padx=(25, 0))
        ctk.CTkEntry(master=login_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000", show="*").pack(anchor="w", padx=(25, 0))

        #BOTÕES DE LOGIN E CADASTRAR
        def login():
            msg = messagebox.showinfo(title="Estado de login.",message="Login feito com sucesso!")
            pass
        botao_login = ctk.CTkButton(master=login_frame, text="Login", fg_color="#27824F", hover_color="#1A5735", font=("Arial Bold", 12), text_color="#ffffff", width=200, command=login).pack(anchor="w", pady=(40, 0), padx=(35, 0))
        
        def tela_cadastro():
            #Remover o frame de login
            login_frame.pack_forget()

            #Criando tela de cadastro de usuários
            rg_frame = ctk.CTkFrame(master=janela, width=300, height=480, fg_color="#ffffff")
            rg_frame.pack_propagate(0)
            rg_frame.pack(expand=True, side="right")
            titulo = ctk.CTkLabel(master=rg_frame, text="CADASTRE-SE", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 27)).pack(anchor="w", pady=(40, 5), padx=(25, 0))
            sub_tt = ctk.CTkLabel(master=rg_frame, text="Informe todos os dados corretamente.", text_color="#7E7E7E", anchor="w", justify="left", font=("Arial Bold", 12)).pack(anchor="w", padx=(25, 0))

            usuario_entry = ctk.CTkLabel(master=rg_frame, text="  Usuário", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=user_icon, compound="left").pack(anchor="w", pady=(15, 0), padx=(25, 0))
            ctk.CTkEntry(master=rg_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000").pack(anchor="w", padx=(25, 0))

            usuario_entry = ctk.CTkLabel(master=rg_frame, text="  Email", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=email_icon, compound="left").pack(anchor="w", pady=(15, 0), padx=(25, 0))
            ctk.CTkEntry(master=rg_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000").pack(anchor="w", padx=(25, 0))

            usuario_entry = ctk.CTkLabel(master=rg_frame, text="  Senha", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=password_icon, compound="left").pack(anchor="w", pady=(15, 0), padx=(25, 0))
            ctk.CTkEntry(master=rg_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000",show="*").pack(anchor="w", padx=(25, 0))

            usuario_entry = ctk.CTkLabel(master=rg_frame, text="  Confirme a senha", text_color="#2A8C55", anchor="w", justify="left", font=("Arial Bold", 14), image=password_icon, compound="left").pack(anchor="w", pady=(15, 0), padx=(25, 0))
            ctk.CTkEntry(master=rg_frame, width=225, fg_color="#EEEEEE", border_color="#2A8C55", border_width=1, text_color="#000000",show="*").pack(anchor="w", padx=(25, 0))
            
            def back():
                #removendo o frame de cadastro
                rg_frame.pack_forget()

                #devolvendo o frame de login
                login_frame.pack(expand=True, side="right")
                
            back_button = ctk.CTkButton(master=rg_frame, text="VOLTAR", width=100, fg_color="gray", hover_color="#15452A", command=back).place(x=25, y=420)
            
            def save_user():
                msg = messagebox.showinfo(title="Estado do cadastro", message="Parabéns! Usuário cadastrado com sucesso.")
                
                pass
            save_button=ctk.CTkButton(master=rg_frame, text="CADASTRAR", width=100, fg_color="#257A4A", command=save_user).place(x=150, y=420)
    
            pass
                
        botao_cadastro = ctk.CTkButton(master=login_frame, text="Cadastrar", fg_color="#1A5735", hover_color="#15452A", font=("Arial Bold", 12), text_color="#ffffff", width=200, command=tela_cadastro).pack(anchor="w", pady=(20, 0), padx=(35, 0))
        aviso = ctk.CTkLabel(master=login_frame, text="Caso não tenha uma conta, favor cadastre-se.", text_color="#7E7E7E", anchor="w", justify="left", font=("Arial Bold", 11)).pack(anchor="w", padx=(25, 0))

Application()