from customtkinter import *
import tkinter
from PIL import Image

app = CTk()
app.geometry("856x645")
app.resizable(0,0)
app.title("EXTINAGER")
set_appearance_mode("light")

sidebar_frame = CTkFrame(master=app, fg_color="#2A8C55",  width=176, height=650, corner_radius=0)
sidebar_frame.pack_propagate(0)
sidebar_frame.pack(fill="y", anchor="w", side="left")

logo_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/logo.png")
logo_img = CTkImage(dark_image=logo_img_data, light_image=logo_img_data, size=(77.68, 85.42))

CTkLabel(master=sidebar_frame, text="", image=logo_img).pack(pady=(38, 0), anchor="center")

analytics_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/analytics_icon.png")
analytics_img = CTkImage(dark_image=analytics_img_data, light_image=analytics_img_data)

CTkButton(master=sidebar_frame, image=analytics_img, text="Mapeamento", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(60, 0))

package_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/package_icon.png")
package_img = CTkImage(dark_image=package_img_data, light_image=package_img_data)

CTkButton(master=sidebar_frame, image=package_img, text="Colaborador", fg_color="#fff", font=("Arial Bold", 14), text_color="#2A8C55", hover_color="#eee", anchor="w").pack(anchor="center", ipady=5, pady=(16, 0))

list_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/list_icon.png")
list_img = CTkImage(dark_image=list_img_data, light_image=list_img_data)
CTkButton(master=sidebar_frame, image=list_img, text="Extintor", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(16, 0))

returns_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/returns_icon.png")
returns_img = CTkImage(dark_image=returns_img_data, light_image=returns_img_data)
CTkButton(master=sidebar_frame, image=returns_img, text="Returns", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(16, 0))

settings_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/settings_icon.png")
settings_img = CTkImage(dark_image=settings_img_data, light_image=settings_img_data)
CTkButton(master=sidebar_frame, image=settings_img, text="Settings", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(16, 0))

person_img_data = Image.open("C:/Users/janas/Desktop/EXINTGER 2/EXTINAGER/customtkinter-examples/Inventory Management/person_icon.png")
person_img = CTkImage(dark_image=person_img_data, light_image=person_img_data)
CTkButton(master=sidebar_frame, image=person_img, text="Account", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(160, 0))
CTkButton(master=sidebar_frame, image=person_img, text="Account", fg_color="transparent", font=("Arial Bold", 14), hover_color="#207244", anchor="w").pack(anchor="center", ipady=5, pady=(160, 0))

main_view = CTkFrame(master=app, fg_color="#fff",  width=680, height=650, corner_radius=0)
main_view.pack_propagate(0)
main_view.pack(side="left")


CTkLabel(master=main_view, text="Cadastro de Colaborador", font=("Arial Black", 25), text_color="#2A8C55").pack(anchor="nw", pady=(20,0), padx=27)

CTkLabel(master=main_view, text="Nome", font=("Arial Bold", 17), text_color="#52A476").pack(anchor="nw", pady=(25,0), padx=27)
CTkEntry(master=main_view, fg_color="#F0F0F0", border_width=0).pack(fill="x", pady=(12,0), padx=27, ipady=5)

grid = CTkFrame(master=main_view, fg_color="transparent")
grid.pack(fill="both", padx=27, pady=(0,0))

CTkLabel(master=grid, text="CPF", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=0, column=0, sticky="w", pady=(10,0))
CTkEntry(master=grid, fg_color="#F0F0F0", border_width=0, width=300).grid(row=1, column=0, ipady=5, pady=(0,0))

CTkLabel(master=grid, text="Data de Nascimento", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=0, column=1, sticky="w", padx=(25,0), pady=(10,0))
CTkEntry(master=grid, fg_color="#F0F0F0", border_width=0, width=300).grid(row=1, column=1, ipady=5, padx=(24,0), pady=(0,0))

CTkLabel(master=grid, text="Contato", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=2, column=0, sticky="w", pady=(10,0))
CTkEntry(master=grid, fg_color="#F0F0F0", border_width=0, width=300).grid(row=3, column=0, ipady=5, pady=(0,0))

CTkLabel(master=grid, text="Função", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=2, column=1, sticky="w", padx=(25,0), pady=(10,0))
CTkEntry(master=grid, fg_color="#F0F0F0", border_width=0, width=300).grid(row=3, column=1, ipady=5, padx=(24,0), pady=(0,0))

CTkLabel(master=grid, text="EPI da Função", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=4, column=1, sticky="w", padx=(25,0), pady=(10,0))
CTkEntry(master=grid, fg_color="#F0F0F0", border_width=0, width=300).grid(row=5, column=1, ipady=5, padx=(24,0), pady=(0,0))

CTkLabel(master=grid, text="Status do Treinamento", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=6, column=1, sticky="w", pady=(10, 0), padx=(25,0))

status_var = tkinter.IntVar(value=0)

CTkRadioButton(master=grid, variable=status_var, value=0, text="Em andamento", font=("Arial Bold", 14), text_color="#52A476", fg_color="#52A476", border_color="#52A476", hover_color="#207244").grid(row=7, column=1, sticky="w", pady=(0,0), padx=(25,0))
CTkRadioButton(master=grid, variable=status_var, value=1,text="Finalizado", font=("Arial Bold", 14), text_color="#52A476", fg_color="#52A476", border_color="#52A476", hover_color="#207244").grid(row=8, column=1, sticky="w", pady=(0,25), padx=(25,0))


#CTkLabel(master=grid, text="Quantity", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=6, column=0, sticky="w", pady=(42, 0))

#quantity_frame = CTkFrame(master=grid, fg_color="transparent")
#quantity_frame.grid(row=7, column=0, pady=(21,0), sticky="w")
#CTkButton(master=quantity_frame, text="-", width=25, fg_color="#2A8C55", hover_color="#207244", font=("Arial Black", 16)).pack(side="left", anchor="w")
#CTkLabel(master=quantity_frame, text="01", text_color="#2A8C55", font=("Arial Black", 16)).pack(side="left", anchor="w", padx=10)
#CTkButton(master=quantity_frame, text="+", width=25,  fg_color="#2A8C55",hover_color="#207244", font=("Arial Black", 16)).pack(side="left", anchor="w")

CTkLabel(master=grid, text="Treinamento", font=("Arial Bold", 17), text_color="#52A476", justify="left").grid(row=4, column=0, sticky="w", pady=(10, 0))
CTkTextbox(master=grid, fg_color="#F0F0F0", width=300, corner_radius=8).grid(row=5, column=0, rowspan=5, sticky="w", pady=(5, 0), ipady=5)

actions = CTkFrame(master=main_view, fg_color="transparent")
actions.pack(fill="both")

CTkButton(master=actions, text="Voltar", width=200, fg_color="transparent", font=("Arial Bold", 17), border_color="#2A8C55", hover_color="#eee", border_width=2, text_color="#2A8C55").place(x=120, y=30)
CTkButton(master=actions, text="Cadastrar", width=200, font=("Arial Bold", 17), hover_color="#207244", fg_color="#2A8C55", text_color="#fff").place(x=380, y=30)


app.mainloop()